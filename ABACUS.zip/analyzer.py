"""
analyzer.py
────────────
Runs the AI pipeline over every video in a journey, in order, building
the final VideoResult/ViolationResult objects. Detection logic, violation
criteria, confidence thresholds and frame-sampling are UNCHANGED — every
fix below is purely about processing lifecycle, evidence persistence
ordering, resource cleanup and recovery.

CVVRS reliability fixes applied in this file:
  • Fix 2  — every video now moves through an explicit, durably-recorded
             state: PENDING → PROCESSING → FINALIZING → COMPLETED, or
             PROCESSING → FAILED / INTERRUPTED. See checkpoint_store.py.
  • Fix 3  — a durable checkpoint (journey_id, job_id, video_id,
             sequence_no, status, processed_frame_count, total_frames,
             violations, evidence_frame_paths, processing_time,
             last_processed_timestamp) is written after every state
             transition, so completed videos never depend on in-memory
             state surviving a crash.
  • Fix 4/5 — evidence persistence is now ATOMIC with video completion:
             `_persist_and_release_video_evidence()` (uploads suspected
             evidence frames to S3 and records their real S3 keys) now
             runs BEFORE `video_done_cb(ok=True, ...)` fires, and the
             crash-recovery snapshot (`_build_partial_video_result`) now
             carries the REAL S3 frame paths instead of an
             unconditional `[]`. Previously video_done_cb (which is what
             the parent process treats as "this video is safely done"
             for recovery purposes) fired BEFORE evidence was persisted,
             so any interruption after that point — even one that
             happened AFTER the frames were actually uploaded moments
             later — would recover that video with framePaths=[].
  • Fix 6  — per-video progress is reported via an optional
             `video_progress_cb(video_id, current_frame, processed_frames,
             total_frames, last_progress_time)` callback, wired into
             GadgetDetectionPipeline's own frame-loop progress_cb (see
             main.py). Used by the watchdog in consumer.py to tell a
             slow-but-healthy video apart from a stalled one.
  • Fix 7  — `analyze_journey()` accepts optional `initial_time_offset` /
             `initial_frame_offset` so a RETRY of only the remaining
             (not-yet-completed) videos in a journey — after a stuck
             video was detected and its worker discarded, see
             consumer.py's watchdog — keeps journey-global timestamps
             continuous instead of restarting from zero.
"""

from __future__ import annotations

import dataclasses
import gc
import json
import logging
import os
import shutil
import tempfile
import threading
import time
from typing import Dict, List, Tuple

import cv2

try:
    import psutil
    _PSUTIL_AVAILABLE = True
except ImportError:
    psutil = None
    _PSUTIL_AVAILABLE = False

from models import VideoJob, VideoResult, ViolationResult
from s3_service import upload_frame, upload_frame_from_path, download_frame

# Import the existing pipeline and store — unchanged
from main import GadgetDetectionPipeline
from utils.violation_store import ViolationStore, _decode_frame, _encode_frame

# NEW — LLM verification gate (Qwen2.5-VL via Ollama). Every candidate
# violation is re-checked by this module before its frame is uploaded to
# S3 or included in the completion payload. See llm_verifier.py.
import llm_verifier

# Fix 2/3 — durable per-video state/checkpoint store (see checkpoint_store.py)
import checkpoint_store

log = logging.getLogger("analyzer")

# OUTPUTS_ROOT mirrors the constant inside violation_store.py
OUTPUTS_ROOT = "outputs"


# ── Memory / resource diagnostics (Fix 5) ──────────────────────────────────────

_PROCESS = psutil.Process(os.getpid()) if _PSUTIL_AVAILABLE else None


def _rss_gb() -> float:
    """Current process resident set size, in GB. Returns -1.0 if psutil is unavailable."""
    if _PROCESS is None:
        return -1.0
    try:
        return _PROCESS.memory_info().rss / (1024 ** 3)
    except Exception:
        return -1.0


def _log_resource_snapshot(label: str, job_id: str = "", violations: int = -1) -> None:
    """
    Emit a single-line resource snapshot. `label` is one of:
    'VIDEO START', 'VIDEO END', 'JOURNEY START', 'JOURNEY END'.

    Also reports GPU memory state (via resource_manager, imported lazily
    so analyzer.py has no hard dependency on it being importable) — this
    gives Phase 9 leak-detection visibility into CUDA usage alongside the
    existing RSS/thread numbers, without changing what this function
    already logs for RSS/threads.
    """
    rss        = _rss_gb()
    thread_cnt = threading.active_count()
    rss_str    = f"{rss:.3f}GB" if rss >= 0 else "n/a (psutil unavailable)"
    viol_str   = f"  VIOLATIONS={violations}" if violations >= 0 else ""

    gpu_str = ""
    try:
        from resource_manager import get_gpu_memory_info
        gpu_info = get_gpu_memory_info()
        if gpu_info.available:
            gpu_str = (
                f"  GPU_reserved={gpu_info.reserved_gb:.3f}GB"
                f"/{gpu_info.total_gb:.3f}GB ({gpu_info.used_fraction*100:.1f}%)"
            )
    except Exception:
        pass

    print(
        f"[MEMORY {label}]  job={job_id}  RSS={rss_str}  THREADS={thread_cnt}"
        f"{viol_str}{gpu_str}"
    )


# ── Helpers ───────────────────────────────────────────────────────────────────

def _video_meta(path: str) -> Tuple[float, float, int, float]:
    """Returns (duration_seconds, fps, total_frames, size_mb)."""
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        return 0.0, 25.0, 0, 0.0
    fps   = cap.get(cv2.CAP_PROP_FPS) or 25.0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    cap.release()
    duration = total / fps if fps > 0 and total > 0 else 0.0
    size_mb  = round(os.path.getsize(path) / 1_000_000, 2) if os.path.isfile(path) else 0.0
    return duration, fps, total, size_mb


def _fmt_duration(seconds: float) -> str:
    """Converts float seconds to 'H:MM:SS' string."""
    t  = int(seconds)
    hh = t // 3600
    mm = (t % 3600) // 60
    ss = t % 60
    return f"{hh}:{mm:02d}:{ss:02d}"


def _event_type_to_violation_type(event_type: str) -> str:
    """
    Map internal event_type strings → CVVRS API ViolationType enum values.

    CVVRS types: PHONE_USAGE | DROWSY | DISTRACTION | EATING |
                 EYES_CLOSED | POSTURE_ALERT | HAND_TO_EAR | SEAT_ABSENCE

    NEW — additive: "hand_raise" is not one of the CVVRS enum values above
    (it's a new, non-violation compliance event from HandRaiseDetector).
    Per spec, its violationType string is the literal "Hand Raise on
    signaling" rather than an upper-snake-case enum. If/when the CVVRS
    backend adds a dedicated enum member for this event, update the value
    below to match — nothing else in the pipeline needs to change.
    """
    return {
        "phone_use":       "PHONE_USAGE",
        "seat_absence":    "SEAT_ABSENCE",
        "drowsy":          "DROWSY",
        "sleeping":        "DROWSY",
        "sleeping_absent": "DROWSY",
        "distraction":     "DISTRACTION",
        "eating":          "EATING",
        "eyes_closed":     "EYES_CLOSED",
        "posture_alert":   "POSTURE_ALERT",
        "hand_to_ear":     "HAND_TO_EAR",
        "hand_raise":      "Hand Raise on signaling",
        # NEW — additive: RSL Hand Brake post-verification (see
        # detector/rsl_hand_brake_verifier.py). Only ever created alongside
        # an already-confirmed "hand_raise" violation on the exact same
        # frame, never on its own.
        "rsl_hand_brake":  "RSL Hand Brake Held",
        # NEW — additive: curve-checking (detector/curve_checking.py). Like
        # "hand_raise", this is a positive/required-procedure compliance
        # event (ALP looked outside the door during a curve), not a CVVRS
        # violation enum. Same "literal string, not upper-snake-case" rule.
        "curve_checking":  "Curve Checking on outside view",
    }.get(event_type.lower(), event_type.upper())


def _severity_for_risk(risk_score: float) -> str:
    """
    Map risk score → severity string.

    Tiers (aligned with CVVRS severity reference):
        >= 95  → CRITICAL
        >= 80  → HIGH
        >= 50  → MEDIUM
        <  50  → LOW
    """
    if risk_score >= 95:
        return "CRITICAL"
    if risk_score >= 80:
        return "HIGH"
    if risk_score >= 50:
        return "MEDIUM"
    return "LOW"


def _local_frame_path(vstore: ViolationStore, relative_path: str) -> str:
    """
    Convert the relative frame path stored by ViolationStore._save_frame()
    back to an absolute local disk path.

    _save_frame() returns:  "<analysis_id>/frames/<filename>"
    The actual disk path is: "outputs/<analysis_id>/frames/<filename>"
    """
    filename = os.path.basename(relative_path)
    return os.path.join(OUTPUTS_ROOT, vstore.analysis_id, "frames", filename)


def _frame_filename_for_video(v, video_id: int, sequence_no: int) -> str:
    """
    Same filename convention as _frame_filename() (below), extended with
    video_id and the video's sequence_no so every evidence frame persisted
    to S3 during per-video processing (see
    _persist_and_release_video_evidence()) can be traced back to its
    job/journey/video/sequence purely from its filename. job_id/journey_id
    are already encoded in the S3 folder prefix (folder_name, passed to
    upload_frame_from_path() unchanged) -- this only adds the two pieces
    that prefix doesn't carry.
    """
    distraction   = "_".join(sorted(v.events))
    filename_time = v.time_str.replace(":", "-")
    return f"video{video_id}_seq{sequence_no}_{distraction}_{filename_time}_{v.frame_index}.jpg"


def _persist_and_release_video_evidence(
    job_id:        str,
    journey_id:    int,
    folder_name:   str,
    shared_vstore: ViolationStore,
    video_path:    str,
    db_filename:   str,
    video_id:      int,
    sequence_no:   int,
) -> None:
    """
    Upload THIS video's suspected evidence frames to S3 immediately after
    its own processing finishes, then release the local copies, instead of
    carrying them in the worker (in memory or on local disk) until the
    entire journey finishes.

    This is the only change to the evidence-frame lifecycle: detector
    behaviour, thresholds, timers and LLM verification logic are untouched.
    Suspected-violation frames still flow through the exact same,
    unmodified ViolationStore.extract_violation_frames() (decodes any
    in-memory annotated_frame, or re-seeks video_path via local_time_str)
    -- this function only adds an S3 upload + local cleanup step right
    after that, per video, instead of once for the whole journey at the
    very end.

    Uploaded frames are NOT deleted from S3 -- they are downloaded again by
    the existing journey-end LLM verification loop in analyze_journey()
    (see download_frame() usage in the "Case 2" branch below).
    """
    # Snapshot which violations belong to THIS video and don't yet have
    # evidence persisted anywhere, before extract_violation_frames() below
    # sets v.frame_path for exactly this set (and clears their
    # annotated_frame, if any).
    mine = [
        v for v in shared_vstore._violations
        if v.source_filename == db_filename and v.frame_path is None
    ]
    if not mine:
        return

    # ── Root-cause fix (0 frames saved for videos 3/4) ─────────────────────
    # ViolationStore.extract_violation_frames() (unmodified — shared with
    # standalone/CLI mode, see utils/violation_store.py) matches violations
    # to a video purely by comparing os.path.basename(video_path) against
    # each violation's v.source_filename. It assumes the path it's given
    # is named like the real/original video file.
    #
    # In journey/batch mode (this function), `video_path` is actually
    # `tmp_path` — the video downloaded to a RANDOMLY-NAMED local temp file
    # (e.g. "/tmp/tmpu_9l0ypv.mp4"), whose basename never equals
    # db_filename (e.g. "003_ch04_20260202030309.mp4", the name
    # v.source_filename was recorded with in main.py). That mismatch made
    # extract_violation_frames()'s internal filter match nothing, hence
    # "[ViolationStore] 0 frames saved for 'tmpu_9l0ypv.mp4'" and
    # "Persisted 0/16" / "Persisted 0/4" in the logs even though 16 and 4
    # suspected violations existed for those videos.
    #
    # Fix: give extract_violation_frames() a same-content path whose
    # basename IS db_filename (a symlink to the real tmp file — no extra
    # video-sized disk copy), instead of changing
    # extract_violation_frames() itself, which other callers (standalone
    # mode, where video_path's basename already equals source_filename)
    # rely on unmodified.
    alias_dir  = tempfile.mkdtemp(prefix="evidence_src_")
    alias_path = os.path.join(alias_dir, db_filename)
    try:
        try:
            os.symlink(os.path.abspath(video_path), alias_path)
        except OSError:
            # Symlinks unsupported/denied on this filesystem — fall back
            # to a real copy so extraction still works.
            shutil.copy2(video_path, alias_path)

        # Unmodified existing extraction logic -- writes local JPEGs under
        # outputs/<analysis_id>/frames/, sets v.frame_path to the local
        # relative path, and clears v.annotated_frame for every violation
        # in `mine`.
        shared_vstore.extract_violation_frames(alias_path)
    finally:
        shutil.rmtree(alias_dir, ignore_errors=True)

    uploaded = 0
    for v in mine:
        if not v.frame_path:
            continue  # extraction failed for this one (e.g. seek failure) -- nothing to persist
        local_path = _local_frame_path(shared_vstore, v.frame_path)
        if not os.path.isfile(local_path):
            continue

        filename = _frame_filename_for_video(v, video_id, sequence_no)
        try:
            s3_key = upload_frame_from_path(
                local_path, journey_id, filename=filename, folder_name=folder_name,
            )
        except Exception as exc:
            # Non-fatal: leave v.frame_path pointing at the local file so
            # the existing journey-end LLM-verification loop can still
            # find and use it (its "local file exists" branch), and the
            # evidence is not lost. It will simply stay on local disk a
            # little longer than the normal case for this one frame.
            print(f"[Analyzer:{job_id}]  Evidence-frame S3 upload failed for "
                  f"{local_path} (video_id={video_id}): {exc} -- keeping local copy")
            continue

        v.frame_path = s3_key
        uploaded += 1
        # Release the local file now that it's safely in S3 -- this is the
        # actual memory/disk-footprint fix: the next video no longer
        # carries this video's evidence frames.
        try:
            os.remove(local_path)
        except OSError:
            pass

    print(f"[Analyzer:{job_id}]  Persisted {uploaded}/{len(mine)} suspected "
          f"evidence frame(s) to S3 for video_id={video_id} seq={sequence_no} "
          f"({db_filename}); released local copies.")


def _hms_to_seconds(hms: str) -> float:
    """
    Convert "H:MM:SS" or "HH:MM:SS" to float seconds.
    Returns 0.0 on any parse error.
    """
    try:
        parts = hms.strip().split(":")
        if len(parts) == 3:
            return int(parts[0]) * 3600 + int(parts[1]) * 60 + float(parts[2])
        if len(parts) == 2:
            return int(parts[0]) * 60 + float(parts[1])
        return float(parts[0])
    except Exception:
        return 0.0


# ── Main entry point ──────────────────────────────────────────────────────────

def _build_partial_video_result(job_id: str, vj, db_filename: str, meta: dict,
                                  shared_vstore) -> dict | None:
    """
    Best-effort VideoResult snapshot for ONE video, built immediately after
    that video's pipeline.run() AND its evidence-frame persistence
    (`_persist_and_release_video_evidence()`) have both completed.

    This exists purely so a crash-recovery completion payload (see
    consumer.py's interruption handling — journey interrupted after at
    least one video already succeeded) can carry the real violation data
    for videos that finished before the interruption, instead of losing
    them and reporting them as failed too.

    Fix 4/5 — this snapshot now carries the REAL S3 evidence-frame path
    (v.frame_path) for every violation, because the caller guarantees
    this is only built AFTER `_persist_and_release_video_evidence()` has
    already uploaded this video's evidence and set v.frame_path to the
    real S3 key. Previously this was built (and video_done_cb fired)
    BEFORE that upload step ran, so framePaths was unconditionally `[]`
    here even when the frames were, moments later, genuinely in S3 —
    exactly the "framePaths empty despite frames being on S3" defect.

    NOTE: this snapshot is still captured BEFORE the journey-wide
    dedup/merge step (which only runs once, after every video in the
    journey has been attempted), so violations are not yet deduplicated
    against other videos in the journey. A normal, uninterrupted journey
    completion never uses this snapshot — it always uses the fully
    deduped + frame-uploaded build at the end of this function, unchanged.
    This is only ever consumed as a fallback for the interrupted case.
    """
    try:
        raw_viols = [v for v in shared_vstore._violations
                     if getattr(v, "source_filename", None) == db_filename]
        violations = []
        for v in raw_viols:
            journey_ts = float(v.timestamp) if hasattr(v, "timestamp") else 0.0
            local_ts   = _hms_to_seconds(getattr(v, "local_time_str", "0:00:00"))
            violations.append({
                "violationType":          _event_type_to_violation_type(v.type),
                "severity":               _severity_for_risk(v.risk_score),
                "confidence":             round(v.confidence * 100, 2),
                "riskScore":              float(v.risk_score),
                "timestamp":              journey_ts,
                "originalVideoTimestamp": local_ts,
                # Fix 4/5: real S3 key, not an unconditional [] — populated
                # by _persist_and_release_video_evidence() before this
                # function is ever called (see analyze_journey()'s loop).
                "framePaths":             [v.frame_path] if v.frame_path else [],
                "status":                 getattr(v, "status", "TRUE") == "TRUE",
                "role":                   getattr(v, "role", None),
            })
        return {
            "videoId":           vj.video_id,
            "videoName":         db_filename,
            "sequenceNo":        vj.sequence_no,
            "durationSeconds":   meta["duration_seconds"],
            "durationFormatted": meta["duration_formatted"],
            "fps":               meta["fps"],
            "sizeMb":            meta["size_mb"],
            "originalS3Key":     vj.s3_key,
            "violations":        violations,
        }
    except Exception as exc:
        print(f"[Analyzer:{job_id}]  _build_partial_video_result failed "
              f"(non-fatal, crash-recovery snapshot only): {exc}")
        return None


def analyze_journey(
    job_id:        str,
    journey_id:    int,
    folder_name:   str,                  # e.g. "journeys/1/2026-06-10/JRN-..."
    video_jobs:    List[VideoJob],
    tmp_paths:     Dict[int, str],       # video_id → local tmp file path
    progress_cb    = None,               # optional callable(pct, msg, current_video)
    video_done_cb  = None,               # optional callable(video_id, ok, error, error_type, stack_trace, reason, video_result)
    video_progress_cb = None,            # Fix 6: optional callable(video_id, current_frame, processed_frames, total_frames, last_progress_time)
    initial_time_offset:  float = 0.0,   # Fix 7: seed for a retry-of-remaining-videos continuation call
    initial_frame_offset: int   = 0,     # Fix 7: seed for a retry-of-remaining-videos continuation call
) -> Tuple[List[VideoResult], float, Dict[int, str]]:
    """
    Run the full detection pipeline over all videos in a journey.

    Parameters
    ──────────
    job_id        : RabbitMQ job ID (used for logging only).
    journey_id    : Journey ID.
    folder_name   : Journey folder prefix used for S3 frame key construction,
                    e.g. "journeys/1/2026-06-10/JRN-20260610-1-ABC123".
    video_jobs    : List of VideoJob objects (will be sorted by sequence_no).
    tmp_paths     : Mapping of video_id → absolute local temp file path.
    progress_cb   : Optional callable(pct, msg, current_video_idx) for updates.
    video_done_cb : Optional callable(video_id, ok, error, error_type,
                    stack_trace, reason, video_result) fired immediately after
                    each video finishes (success or failure). Used by
                    journey_runner.py to push per-video progress events to the
                    parent process via a multiprocessing.Queue so the parent
                    knows which videos completed before a native crash kills
                    the child.
    video_progress_cb : Fix 6 — optional callable(video_id, current_frame,
                    processed_frames, total_frames, last_progress_time) fired
                    periodically WHILE a video is being processed (not just
                    at the end). Used by consumer.py's watchdog to tell a
                    slow-but-healthy video apart from a genuinely stalled one.
    initial_time_offset / initial_frame_offset : Fix 7 — when this call is a
                    RETRY covering only the videos that hadn't yet completed
                    in a previous, watchdog-interrupted attempt at the same
                    journey, seed the cumulative offsets with the already-
                    completed videos' total duration/frames so journey-global
                    violation timestamps stay continuous across the retry
                    instead of restarting at zero.

    Returns
    ───────
    (video_results, total_wall_clock_seconds, failed_videos)
    """
    # Sort by sequence_no — critical for correct time/frame offset continuity
    ordered  = sorted(video_jobs, key=lambda v: v.sequence_no)
    n_videos = len(ordered)

    # One shared ViolationStore for the whole journey.
    analysis_id   = f"journey_{journey_id}"
    shared_vstore = ViolationStore(
        analysis_id     = analysis_id,
        train_detail_id = journey_id,
    )

    time_offset  = initial_time_offset
    frame_offset = initial_frame_offset
    wall_start   = time.time()

    # ── Fix 2/3: durable per-video checkpoint — every video starts PENDING ───
    try:
        checkpoint_store.init_journey(
            job_id, journey_id, [vj.video_id for vj in ordered],
            sequence_by_id={vj.video_id: vj.sequence_no for vj in ordered},
        )
    except Exception as exc:
        print(f"[Analyzer:{job_id}]  checkpoint_store.init_journey failed (non-fatal): {exc}")

    # Per-video metadata cache (keyed by video_id)
    meta_by_id: Dict[int, dict] = {}

    # Track which videos were skipped due to a per-video error so we can
    # still include them in the VideoResult list with zero violations.
    failed_video_ids: set = set()

    # ── Fix 5: memory/resource snapshot — journey start ──────────────────────
    _log_resource_snapshot("JOURNEY START", job_id=job_id,
                            violations=len(shared_vstore._violations))

    # ── Run the AI pipeline over each video ──────────────────────────────────
    for idx, vj in enumerate(ordered):
        tmp_path    = tmp_paths[vj.video_id]
        db_filename = os.path.basename(vj.s3_key)

        duration, fps, total_frames, size_mb = _video_meta(tmp_path)

        meta_by_id[vj.video_id] = {
            "duration_seconds":   duration,
            "duration_formatted": _fmt_duration(duration),
            "fps":                fps,
            "size_mb":            size_mb,
            "total_frames":       total_frames,
        }

        print(
            f"[Analyzer:{job_id}]  [{idx + 1}/{n_videos}]  "
            f"video_id={vj.video_id}  seq={vj.sequence_no}  "
            f"file={db_filename}  "
            f"time_offset={time_offset:.2f}s  frame_offset={frame_offset}"
        )

        # ── Fix 5: memory/resource snapshot — before this video ──────────────
        _log_resource_snapshot("VIDEO START", job_id=job_id,
                                violations=len(shared_vstore._violations))

        # ── Per-video processing time + RAM consumed tracking ────────────────
        _video_proc_start   = time.time()
        _video_rss_start_gb = _rss_gb()

        # ── Resource lifecycle (Phase 3): GPU threshold safety check ─────────
        # If CUDA memory usage is already at/above the configured threshold
        # before this video even starts, attempting inference is very likely
        # to OOM anyway. Skip this video safely (mark it failed with a clear
        # reason) rather than letting a near-certain CUDA crash take down the
        # whole journey/process. is_gpu_over_threshold() is a no-op (returns
        # False) when CUDA isn't available, so this never affects CPU-only
        # environments.
        try:
            from resource_manager import is_gpu_over_threshold, gpu_cleanup, CUDA_ABORT_THRESHOLD
            if is_gpu_over_threshold():
                print(
                    f"[Analyzer:{job_id}]  GPU memory usage at/above "
                    f"{CUDA_ABORT_THRESHOLD*100:.0f}% threshold — attempting "
                    f"cleanup before video_id={vj.video_id}..."
                )
                gpu_cleanup()
                if is_gpu_over_threshold():
                    print(
                        f"[Analyzer:{job_id}]  GPU still over threshold after "
                        f"cleanup — skipping video_id={vj.video_id} "
                        f"seq={vj.sequence_no} to avoid a near-certain CUDA OOM."
                    )
                    failed_video_ids.add(vj.video_id)
                    try:
                        checkpoint_store.save_checkpoint(
                            job_id, journey_id, vj.video_id, vj.sequence_no,
                            checkpoint_store.INTERRUPTED,
                            total_frames=total_frames,
                        )
                    except Exception:
                        pass
                    if video_done_cb is not None:
                        try:
                            video_done_cb(
                                vj.video_id, False,
                                "Not Processed - Worker Resource Exhaustion",
                                "NOT_PROCESSED", None,
                                "Not Processed - Worker Resource Exhaustion",
                            )
                        except Exception:
                            pass
                    time_offset  += duration
                    frame_offset += total_frames
                    if progress_cb:
                        pct = 10 + int(((idx + 1) / n_videos) * 80)
                        try:
                            progress_cb(pct, f"Analyzed video {idx + 1} of {n_videos}", idx + 1)
                        except Exception as exc:
                            print(f"[Analyzer:{job_id}]  progress_cb error (non-fatal): {exc}")
                    continue
        except ImportError:
            pass  # resource_manager unavailable — proceed without the check

        # ── Fix 2/3: durable checkpoint — this video is now PROCESSING ───────
        try:
            checkpoint_store.save_checkpoint(
                job_id, journey_id, vj.video_id, vj.sequence_no,
                checkpoint_store.PROCESSING,
                total_frames=total_frames,
            )
        except Exception as exc:
            print(f"[Analyzer:{job_id}]  checkpoint save (PROCESSING) failed (non-fatal): {exc}")

        # ── Fix 6: per-video progress reporting ───────────────────────────────
        # Bind video_id into a closure over the caller-supplied
        # video_progress_cb, and ALSO checkpoint progress periodically so the
        # durable record (Fix 3) reflects real in-flight progress, not just
        # the terminal state. Both are best-effort — never allowed to disrupt
        # the actual frame loop.
        _last_ckpt_progress_frame = 0

        def _on_pipeline_progress(current_frame: int, processed_frames: int,
                                    total_frames_: int, last_progress_time: float,
                                    _vid=vj.video_id, _seq=vj.sequence_no) -> None:
            nonlocal _last_ckpt_progress_frame
            if video_progress_cb is not None:
                try:
                    video_progress_cb(_vid, current_frame, processed_frames,
                                       total_frames_, last_progress_time)
                except Exception:
                    pass
            # Throttle the (relatively expensive, disk-writing) checkpoint
            # update independently from the (cheap, in-memory-queue) watchdog
            # signal above — every ~500 processed frames is plenty for
            # recovery purposes.
            if processed_frames - _last_ckpt_progress_frame >= 500:
                _last_ckpt_progress_frame = processed_frames
                try:
                    checkpoint_store.save_checkpoint(
                        job_id, journey_id, _vid, _seq,
                        checkpoint_store.PROCESSING,
                        processed_frame_count=processed_frames,
                        total_frames=total_frames_,
                    )
                except Exception:
                    pass

        pipeline = GadgetDetectionPipeline(
            source           = tmp_path,
            analysis_id      = analysis_id,
            train_detail_id  = journey_id,
            save             = False,
            display          = False,
            shared_vstore    = shared_vstore,
            time_offset      = time_offset,
            frame_offset     = frame_offset,
            source_filename  = db_filename,
            progress_cb      = _on_pipeline_progress,
        )

        # ── Per-video error isolation (Scenario 1 & 2) ───────────────────────
        #
        # Two distinct failure classes require different treatment:
        #
        # SCENARIO 2 — Video-specific failures (corrupted file, bad codec,
        # FFmpeg error, decode error, etc.):
        #   • Mark only this video as FAILED.
        #   • Fire video_done_cb with ok=False and error_type=PROCESSING_ERROR
        #     (or a more specific classifier via classify_video_error).
        #   • Continue processing the next video in the loop.
        #
        # SCENARIO 1 — Worker/memory-level failures (CUDA OOM, OpenCV
        # OutOfMemoryError, MemoryError, std::bad_alloc, "Failed to allocate",
        # etc.) that Python CAN still raise as exceptions (as opposed to the
        # native crash that kills the process outright — that is handled by
        # the subprocess isolation in journey_runner.py/consumer.py):
        #   • Mark this video as FAILED with error_type=RESOURCE_EXHAUSTION.
        #   • Mark EVERY REMAINING video (not yet processed) as NOT_PROCESSED
        #     via video_done_cb with reason="Not Processed - Worker Resource
        #     Exhaustion", so the parent immediately calls the Failure API for
        #     each one — preserving all work done before this point.
        #   • Break out of the loop — do NOT attempt any more videos.
        #   • Preserved: all VideoResult / violation data for videos 1..idx-1.
        #
        # We catch BaseException (not just Exception) because pipeline.run()
        # calls sys.exit(1) on unreadable files — SystemExit is a BaseException.
        # KeyboardInterrupt and SystemExit are re-raised so they propagate
        # to the consumer's outer handler (nack + DLQ) instead of being
        # treated as per-video errors.
        #
        # video_done_cb is fired after every video (success OR failure) so the
        # parent subprocess monitor always knows which videos finished before a
        # native crash kills the child process. It is best-effort: errors inside
        # the callback are swallowed so they never disrupt the processing loop.
        import traceback as _tb
        try:
            from callback_client import is_resource_exhaustion_error, classify_video_error
            _have_classifier = True
        except ImportError:
            _have_classifier = False

        _worker_oom    = False   # True when this video hit a resource-exhaustion error
        _video_exc_for_cb: BaseException | None = None
        try:
            pipeline.run()
        except KeyboardInterrupt:
            raise
        except SystemExit:
            raise
        except BaseException as video_exc:
            _video_exc_for_cb = video_exc
            # Classify: is this a worker-level memory failure (Scenario 1) or
            # an ordinary video-specific failure (Scenario 2)?
            if _have_classifier and is_resource_exhaustion_error(video_exc):
                _worker_oom = True
                error_type_for_cb = "RESOURCE_EXHAUSTION"
            elif _have_classifier:
                error_type_for_cb = classify_video_error(video_exc)
            else:
                # Fallback classification without callback_client available
                _worker_oom = isinstance(video_exc, MemoryError) or any(
                    sig in f"{type(video_exc).__name__}: {video_exc}".lower()
                    for sig in ("outofmemoryerror", "out of memory",
                                "failed to allocate", "bad_alloc",
                                "cannot allocate memory", "resource exhaust")
                )
                error_type_for_cb = "RESOURCE_EXHAUSTION" if _worker_oom else "PROCESSING_ERROR"

            print(
                f"[Analyzer:{job_id}]  {'WORKER OOM' if _worker_oom else 'WARNING'} "
                f"— video_id={vj.video_id} seq={vj.sequence_no} "
                f"{'RESOURCE EXHAUSTION' if _worker_oom else 'FAILED (skipping)'}: "
                f"{video_exc!r}"
            )
            failed_video_ids.add(vj.video_id)

        # ── Fix 4/5: persist evidence BEFORE reporting this video as done ─────
        # Evidence-frame persistence (S3 upload) must complete, and the
        # video's checkpoint must reach a terminal state, BEFORE video_done_cb
        # fires — video_done_cb(ok=True) is what the parent treats as "this
        # video is safely, durably done" for crash-recovery purposes, so it
        # must never fire ahead of the work it's claiming is finished.
        #
        # This runs for the worker-OOM video itself too (best-effort — any
        # evidence already recorded for it before the OOM should still be
        # persisted, not lost), but NOT for the "remaining, never-started"
        # videos after it, which have no evidence to persist.
        try:
            checkpoint_store.save_checkpoint(
                job_id, journey_id, vj.video_id, vj.sequence_no,
                checkpoint_store.FINALIZING,
                processed_frame_count=meta_by_id[vj.video_id].get("total_frames", 0),
                total_frames=meta_by_id[vj.video_id].get("total_frames", 0),
            )
        except Exception as exc:
            print(f"[Analyzer:{job_id}]  checkpoint save (FINALIZING) failed (non-fatal): {exc}")

        del pipeline

        # ── Evidence-frame lifecycle fix ──────────────────────────────────
        # Persist THIS video's suspected evidence frames to S3 now, and
        # release the local/in-memory copies, instead of carrying them in
        # the worker until the whole journey finishes (see
        # _persist_and_release_video_evidence() docstring above). Runs for
        # a successful video, an ordinary per-video failure (Scenario 2),
        # AND the worker-OOM video itself — either way, any evidence already
        # recorded for this video before it finished should be persisted,
        # not lost or carried forward into the next video's memory.
        try:
            _persist_and_release_video_evidence(
                job_id, journey_id, folder_name, shared_vstore,
                tmp_path, db_filename, vj.video_id, vj.sequence_no,
            )
        except Exception as exc:
            print(f"[Analyzer:{job_id}]  Evidence persistence failed for "
                  f"video_id={vj.video_id} (non-fatal): {exc}")

        # ── Fire video_done_cb for the video that just finished ───────────────
        # Called regardless of success or failure so the parent process always
        # has an up-to-date picture of which videos completed before any crash.
        # Now runs AFTER evidence persistence (Fix 4/5) so:
        #   • the crash-recovery snapshot (_build_partial_video_result) carries
        #     REAL S3 evidence-frame paths, never an unconditional [];
        #   • the durable checkpoint (Fix 2/3) only reaches COMPLETED once
        #     inference + evidence upload + result construction are all done.
        _video_ckpt_violations = [
            v.frame_path for v in shared_vstore._violations
            if getattr(v, "source_filename", None) == db_filename and v.frame_path
        ]
        if video_done_cb is not None:
            try:
                if _video_exc_for_cb is None:
                    # Success — also hand back a best-effort result snapshot
                    # (see _build_partial_video_result) so the parent can
                    # preserve this video's real data if the journey gets
                    # interrupted later (crash, OOM, etc.) before the normal
                    # end-of-journey build/dedup step runs. Evidence has
                    # already been persisted above, so framePaths here are
                    # the real S3 keys, not [].
                    _partial_result = _build_partial_video_result(
                        job_id, vj, db_filename, meta_by_id[vj.video_id],
                        shared_vstore,
                    )
                    video_done_cb(
                        vj.video_id,
                        True,   # ok
                        None,   # error
                        None,   # error_type
                        None,   # stack_trace
                        None,   # reason
                        video_result=_partial_result,
                    )
                else:
                    # Per-video failure OR resource-exhaustion failure
                    video_done_cb(
                        vj.video_id,
                        False,                            # ok
                        str(_video_exc_for_cb),           # error
                        error_type_for_cb,                # error_type
                        _tb.format_exc(),                 # stack_trace
                        "Not Processed - Worker Resource Exhaustion"
                            if _worker_oom else None,     # reason
                    )
            except Exception:
                pass  # never let a callback error kill the analysis loop

        # ── Fix 2/3: durable checkpoint — terminal state for this video ──────
        try:
            _ckpt_status = (
                checkpoint_store.INTERRUPTED if _worker_oom else
                (checkpoint_store.FAILED if _video_exc_for_cb is not None else
                 checkpoint_store.COMPLETED)
            )
            checkpoint_store.save_checkpoint(
                job_id, journey_id, vj.video_id, vj.sequence_no, _ckpt_status,
                processed_frame_count=meta_by_id[vj.video_id].get("total_frames", 0),
                total_frames=meta_by_id[vj.video_id].get("total_frames", 0),
                evidence_frame_paths=_video_ckpt_violations,
                processing_time=time.time() - _video_proc_start,
            )
        except Exception as exc:
            print(f"[Analyzer:{job_id}]  checkpoint save (terminal) failed (non-fatal): {exc}")

        # ── Scenario 1: worker OOM — stop the loop, report remaining as NOT_PROCESSED
        if _worker_oom:
            # Advance offsets for this video so accounting is consistent before we stop.
            time_offset  += duration
            frame_offset += total_frames

            # Report every video that comes AFTER this one as NOT_PROCESSED.
            # "After" = sequence_no > current vj's position in the ordered list.
            # We iterate from the NEXT video to the end of ordered.
            remaining_reason = "Not Processed - Worker Resource Exhaustion"
            for remaining_vj in ordered[idx + 1:]:
                remaining_vid = remaining_vj.video_id
                failed_video_ids.add(remaining_vid)
                print(
                    f"[Analyzer:{job_id}]  Marking video_id={remaining_vid} "
                    f"seq={remaining_vj.sequence_no} as NOT_PROCESSED due to "
                    "worker resource exhaustion on a prior video."
                )
                if video_done_cb is not None:
                    try:
                        video_done_cb(
                            remaining_vid,
                            False,                    # ok
                            "Processing stopped due to worker memory failure",
                            "NOT_PROCESSED",          # error_type
                            None,                     # stack_trace
                            remaining_reason,         # reason
                        )
                    except Exception:
                        pass
                # These videos never started at all — leave/record them
                # explicitly PENDING in the durable checkpoint (not
                # INTERRUPTED, which is reserved for a video that had
                # actually started). A later retry submission (Fix 7,
                # consumer.py) is exactly what should pick these back up.
                try:
                    checkpoint_store.save_checkpoint(
                        job_id, journey_id, remaining_vid, remaining_vj.sequence_no,
                        checkpoint_store.PENDING,
                    )
                except Exception:
                    pass

            # Stop processing further videos in this journey.
            _log_resource_snapshot("VIDEO END (OOM-STOP)", job_id=job_id,
                                    violations=len(shared_vstore._violations))

            # ── Per-video processing time + RAM consumed summary (OOM path) ──
            _video_proc_elapsed  = time.time() - _video_proc_start
            _video_rss_end_gb    = _rss_gb()
            _video_rss_delta_gb  = (
                _video_rss_end_gb - _video_rss_start_gb
                if (_video_rss_end_gb >= 0 and _video_rss_start_gb >= 0) else -1.0
            )
            _rss_end_str   = f"{_video_rss_end_gb:.3f}GB" if _video_rss_end_gb >= 0 else "n/a"
            _rss_delta_str = f"{_video_rss_delta_gb:+.3f}GB" if _video_rss_delta_gb != -1.0 else "n/a"
            print(
                f"[Analyzer:{job_id}]  video_id={vj.video_id}  seq={vj.sequence_no}  "
                f"PROCESSING_TIME={_video_proc_elapsed:.2f}s  "
                f"RAM_USED={_rss_end_str}  RAM_CONSUMED(delta)={_rss_delta_str}  (OOM-STOP)"
            )
            # Break out of the for-loop so we move straight to dedup/upload/build.
            break

        # Advance offsets for the next video regardless of success/failure.
        # Using the metadata we already captured keeps offsets consistent for
        # subsequent videos even when this one's pipeline run was skipped.
        time_offset  += duration
        frame_offset += total_frames

        # ── Fix 5: memory/resource snapshot — after this video ───────────────
        _log_resource_snapshot("VIDEO END", job_id=job_id,
                                violations=len(shared_vstore._violations))

        # ── Per-video processing time + RAM consumed summary ─────────────────
        _video_proc_elapsed  = time.time() - _video_proc_start
        _video_rss_end_gb    = _rss_gb()
        _video_rss_delta_gb  = (
            _video_rss_end_gb - _video_rss_start_gb
            if (_video_rss_end_gb >= 0 and _video_rss_start_gb >= 0) else -1.0
        )
        _rss_end_str   = f"{_video_rss_end_gb:.3f}GB" if _video_rss_end_gb >= 0 else "n/a"
        _rss_delta_str = f"{_video_rss_delta_gb:+.3f}GB" if _video_rss_delta_gb != -1.0 else "n/a"
        print(
            f"[Analyzer:{job_id}]  video_id={vj.video_id}  seq={vj.sequence_no}  "
            f"PROCESSING_TIME={_video_proc_elapsed:.2f}s  "
            f"RAM_USED={_rss_end_str}  RAM_CONSUMED(delta)={_rss_delta_str}"
        )

        # Report per-video progress (10%–90% band)
        if progress_cb:
            pct = 10 + int(((idx + 1) / n_videos) * 80)
            try:
                progress_cb(pct, f"Analyzed video {idx + 1} of {n_videos}", idx + 1)
            except Exception as exc:
                print(f"[Analyzer:{job_id}]  progress_cb error (non-fatal): {exc}")

    total_wall_seconds = time.time() - wall_start

    # ── Dedup + merge ─────────────────────────────────────────────────────────
    shared_vstore._deduplicate_by_frame()
    shared_vstore._merge_by_time_window()

    # ── NEW — additive: RSL Hand Brake post-verification ─────────────────────
    # Runs ONLY here — after hand_rise_detector.py has already run over the
    # complete video(s), and only after dedup/merge above have produced the
    # FINAL, single representative frame per confirmed hand-raise episode.
    # This is not a standalone detector and never runs per-frame.
    #
    # For every confirmed "hand_raise" violation, this:
    #   1. re-reads ONLY the SAME already-selected signal frame from the
    #      correct source video (no neighbouring ±2 frame window, never a
    #      full re-scan),
    #   2. sends that single frame directly to Qwen-VL in one call
    #      (detector/rsl_hand_brake_verifier.py → llm_verifier.py) — the
    #      model itself judges signal acknowledgement and whether the
    #      opposite/ALP hand is on the RSL Hand Brake console lever in
    #      that same frame, with NO second MediaPipe pass, and
    #   3. on success, clones the SAME timestamp/journey/video metadata
    #      into a new "rsl_hand_brake" violation, using that same frame
    #      as its evidence and role forced to "ALP".
    #
    # The clone is appended to shared_vstore._violations BEFORE the existing
    # LLM-verification / frame-extraction / S3-upload loop below runs, so
    # that loop — completely unmodified — persists/uploads it exactly the
    # same way it already does for every other violation. Nothing here
    # mutates the original hand_raise violation or any existing logic above.
    try:
        from detector.rsl_hand_brake_verifier import extract_signal_frame, verify_rsl_hand_brake

        _rsl_path_by_filename: Dict[str, str] = {
            os.path.basename(vj.s3_key): tmp_paths[vj.video_id] for vj in ordered
        }
        _rsl_fps_by_filename: Dict[str, float] = {
            os.path.basename(vj.s3_key): meta_by_id.get(vj.video_id, {}).get("fps", 25.0)
            for vj in ordered
        }

        _rsl_new_violations = []

        # Match on `events` (not just `type`) — a hand_raise violation can
        # end up merged with another violation type that happened within
        # the same MERGE_WINDOW, in which case v.type is whichever event
        # came first but "hand_raise" is still present in v.events. This
        # mirrors how close_violation_episode() already matches above.
        for v in [v for v in shared_vstore._violations if "hand_raise" in v.events]:
            src_file   = getattr(v, "source_filename", "")
            local_secs = _hms_to_seconds(getattr(v, "local_time_str", "0:00:00"))

            if v.annotated_frame is not None:
                # Preferred path — reuse the EXACT frame already captured
                # for this violation at detection time (main.py), still in
                # memory at this point (this step runs BEFORE the
                # extract_violation_frames() loop below clears it). This
                # guarantees the Hand Raising LLM check and this RSL check
                # are looking at identical pixels for the identical
                # moment — no second, independent re-seek that could land
                # on a slightly different frame than what was actually
                # verified/shown as evidence. annotated_frame is stored as
                # JPEG bytes (see _encode_frame) — decode before use.
                signal_frame = _decode_frame(v.annotated_frame)
            elif v.frame_path and not os.path.isfile(_local_frame_path(shared_vstore, v.frame_path)):
                # Evidence-frame lifecycle fix: this violation's frame was
                # already persisted to S3 during its own video's per-video
                # processing (see _persist_and_release_video_evidence()),
                # so annotated_frame was cleared and the local copy no
                # longer exists. Download the EXACT same frame back from S3
                # instead of re-seeking the source video, preserving the
                # "identical pixels" guarantee this step relies on.
                try:
                    signal_frame = download_frame(v.frame_path)
                except Exception as exc:
                    print(f"[Analyzer:{job_id}]  RSL verify: could not download "
                          f"evidence frame from S3 ({v.frame_path}): {exc}")
                    signal_frame = None
            else:
                tmp_path = _rsl_path_by_filename.get(src_file, "")
                if not tmp_path or not os.path.isfile(tmp_path):
                    continue
                fps = _rsl_fps_by_filename.get(src_file) or 25.0
                signal_frame = extract_signal_frame(tmp_path, local_secs, fps)

            if signal_frame is None:
                print(f"[Analyzer:{job_id}]  RSL verify: could not read the signal "
                      f"frame for {src_file} @ {local_secs:.2f}s — skipping")
                continue

            verdict = verify_rsl_hand_brake(
                signal_frame, log_label=f"rsl_hand_brake:{src_file}@{local_secs:.2f}s",
            )
            print(f"[Analyzer:{job_id}]  RSL verify for hand_raise "
                  f"frame_index={v.frame_index} src={src_file}: "
                  f"confirmed={verdict['confirmed']} confidence={verdict['confidence']} "
                  f"role={verdict['role']} reason={verdict['reason']!r}")

            if not verdict["confirmed"] or verdict["best_frame"] is None:
                continue

            # Duplicate the exact same timestamp / journey / video /
            # metadata — the type, events, factors, confidence, role
            # (always "ALP" once confirmed) and annotated_frame (the same
            # single signal frame that was sent to Qwen) differ.
            rsl_violation = dataclasses.replace(
                v,
                type            = "rsl_hand_brake",
                events          = ["rsl_hand_brake"],
                confidence      = round(float(verdict["confidence"]), 3),
                factors         = list(set(list(v.factors) + ["rsl_hand_brake", "opposite_hand_on_brake"])),
                # Encode to JPEG bytes rather than store a raw array copy —
                # see _encode_frame() docstring in utils/violation_store.py.
                annotated_frame = _encode_frame(verdict["best_frame"]),
                frame_path      = None,
                status          = "TRUE",
                role            = verdict["role"],
            )
            _rsl_new_violations.append(rsl_violation)

        if _rsl_new_violations:
            shared_vstore._violations.extend(_rsl_new_violations)
            print(f"[Analyzer:{job_id}]  RSL Hand Brake: {len(_rsl_new_violations)} "
                  f"additional violation(s) created from confirmed hand_raise frame(s).")
    except Exception as exc:
        print(f"[Analyzer:{job_id}]  RSL Hand Brake verification step failed (non-fatal): {exc}")

    # ── Extract frames + upload to S3 ───────────────────────────────────────
    #
    # BUG FIX — Wrong frames in violation evidence
    # ─────────────────────────────────────────────
    # The old code called:
    #   for vj in ordered:
    #       shared_vstore.extract_violation_frames(tmp_path)
    #
    # extract_violation_frames() iterates ALL violations in the shared store
    # and seeks to v.frame_index (a GLOBAL frame number across all videos).
    # When called with video_2's path, it seeks to e.g. frame 4500 in video_2
    # — but frame 4500 is from video_1 (frame_index was global, not local).
    # Result: every violation gets a frame from the WRONG video.
    #
    # Fix: build a per-filename path map, then for each violation use its
    # source_filename to open the correct video and seek using local_time_str
    # (seconds within that specific video file) — which is correct regardless
    # of how many videos precede it in the journey.

    # Map db_filename → local tmp path
    path_by_filename: Dict[str, str] = {
        os.path.basename(vj.s3_key): tmp_paths[vj.video_id]
        for vj in ordered
    }

    # LLM verification gate (Qwen2.5-VL via Ollama, see
    # llm_verifier.py / prompt.py). Inserted right before each case's
    # existing upload_frame()/upload_frame_from_path() call. EVERY
    # candidate violation is verified and kept (none are dropped):
    #   • REJECTED  → v.status = "FALSE", v.role = None. The violation
    #                 still flows through into the completion payload,
    #                 just tagged as not confirmed.
    #   • VERIFIED  → v.status = "TRUE", v.role is set to one of
    #                 "LP" / "ALP" / "BOTH" / "AMBIGUOUS".
    # Everything else about Cases 1/2/3 below (how the frame is located)
    # is unchanged.
    n_llm_verified = 0
    n_llm_rejected = 0
    n_llm_skipped  = 0

    for v in shared_vstore._violations:
        # ── Case 1: annotated frame already in memory — upload directly ──────
        if v.annotated_frame is not None:
            filename  = _frame_filename(v)
            # annotated_frame is JPEG bytes (see _encode_frame) — decode to
            # a raw array before handing pixels to the LLM verifier / S3 upload.
            frame_img = _decode_frame(v.annotated_frame)

            verdict = llm_verifier.verify_frame(frame_img, v.type, log_label=filename)
            if verdict["skipped"]:
                n_llm_skipped += 1
            elif verdict["status"] == "FALSE":
                n_llm_rejected += 1
                print(f"[Analyzer:{job_id}]  LLM REJECTED violation "
                      f"(type={v.type} file={filename}): {verdict['reason']}")
            else:
                n_llm_verified += 1
            v.status = verdict["status"]
            v.role   = verdict["role"]

            try:
                s3_key            = upload_frame(frame_img, journey_id,
                                                 filename, folder_name=folder_name)
                v.frame_path      = s3_key
                v.annotated_frame = None
            except Exception as exc:
                print(f"[Analyzer:{job_id}]  In-memory frame upload failed ({filename}): {exc}")
            continue

        # ── Case 2: no frame yet — extract from the correct source video ─────
        if v.frame_path:
            # Already extracted to disk by a previous extract_violation_frames()
            # call (e.g. standalone mode). Upload it.
            local_path = _local_frame_path(shared_vstore, v.frame_path)
            if os.path.isfile(local_path):
                frame_img = cv2.imread(local_path)
                if frame_img is None:
                    print(f"[Analyzer:{job_id}]  Could not read saved frame for "
                          f"LLM check: {local_path} — uploading unverified")
                    verdict = {"verified": True, "status": "TRUE", "role": "AMBIGUOUS",
                               "skipped": True,
                               "reason": "Frame unreadable for LLM check."}
                else:
                    verdict = llm_verifier.verify_frame(frame_img, v.type, log_label=local_path)

                if verdict["skipped"]:
                    n_llm_skipped += 1
                elif verdict["status"] == "FALSE":
                    n_llm_rejected += 1
                    print(f"[Analyzer:{job_id}]  LLM REJECTED violation "
                          f"(type={v.type} file={local_path}): {verdict['reason']}")
                else:
                    n_llm_verified += 1
                v.status = verdict["status"]
                v.role   = verdict["role"]

                try:
                    s3_key       = upload_frame_from_path(local_path, journey_id,
                                                          folder_name=folder_name)
                    v.frame_path = s3_key
                except Exception as exc:
                    print(f"[Analyzer:{job_id}]  Frame upload failed ({local_path}): {exc}")
            else:
                # Evidence-frame lifecycle fix: no local file means this
                # violation's evidence frame was already persisted to S3
                # during its own video's per-video processing (see
                # _persist_and_release_video_evidence()) — v.frame_path is
                # already the S3 key, not a local path. Download it back
                # for the LLM check; it does not need to be re-uploaded
                # (same bytes, same key, already in S3).
                try:
                    frame_img = download_frame(v.frame_path)
                except Exception as exc:
                    print(f"[Analyzer:{job_id}]  Could not download evidence frame "
                          f"from S3 for LLM check ({v.frame_path}): {exc} — uploading unverified")
                    frame_img = None

                if frame_img is None:
                    # FIX — previously this branch left v.status / v.role on
                    # the bare _Violation dataclass defaults ("TRUE" / None)
                    # because verify_frame() was never called here,
                    # producing status=true with role=null in the
                    # completion payload. Tag it the same way the other
                    # "couldn't verify" branches in llm_verifier.py do:
                    # unverified pass-through, so role is never None while
                    # status is TRUE.
                    n_llm_skipped += 1
                    v.status = "TRUE"
                    v.role   = "AMBIGUOUS"
                else:
                    verdict = llm_verifier.verify_frame(frame_img, v.type, log_label=v.frame_path)
                    if verdict["skipped"]:
                        n_llm_skipped += 1
                    elif verdict["status"] == "FALSE":
                        n_llm_rejected += 1
                        print(f"[Analyzer:{job_id}]  LLM REJECTED violation "
                              f"(type={v.type} file={v.frame_path}): {verdict['reason']}")
                    else:
                        n_llm_verified += 1
                    v.status = verdict["status"]
                    v.role   = verdict["role"]
                    # v.frame_path is already the correct, final S3 key —
                    # no re-upload needed, the bytes are identical to what
                    # was just downloaded and verified.
            continue

        # ── Case 3: no frame at all — seek into the correct source video ─────
        src_file = getattr(v, "source_filename", "")
        tmp_path = path_by_filename.get(src_file, "")
        if not tmp_path or not os.path.isfile(tmp_path):
            print(f"[Analyzer:{job_id}]  Cannot find source video for violation "
                  f"(source_filename={src_file!r}) — skipping frame extraction")
            # FIX — see matching comment above: verify_frame() is never
            # reached on this branch either, so tag status/role explicitly
            # instead of leaving role=null on the dataclass default.
            n_llm_skipped += 1
            v.status = "TRUE"
            v.role   = "AMBIGUOUS"
            continue

        # Use local_time_str (seconds within this video) to seek correctly.
        # v.local_time_str is set by record_violation(local_video_time=...) and
        # stored as an "H:MM:SS" string. Convert back to seconds for cv2 seek.
        local_secs = _hms_to_seconds(getattr(v, "local_time_str", "0:00:00"))

        cap = cv2.VideoCapture(tmp_path)
        frame_img = None
        if cap.isOpened():
            cap.set(cv2.CAP_PROP_POS_MSEC, local_secs * 1000.0)
            ret, frame_img = cap.read()
            if not ret:
                # Fallback: try seeking by fraction of duration
                fps   = cap.get(cv2.CAP_PROP_FPS) or 25.0
                total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
                local_frame = int(local_secs * fps)
                cap.set(cv2.CAP_PROP_POS_FRAMES, min(local_frame, max(0, total - 1)))
                ret, frame_img = cap.read()
        cap.release()

        if frame_img is None:
            print(f"[Analyzer:{job_id}]  Frame seek failed for {src_file} "
                  f"@ local_time={local_secs:.2f}s — skipping")
            # FIX — see matching comment above: verify_frame() is never
            # reached on this branch either, so tag status/role explicitly
            # instead of leaving role=null on the dataclass default.
            n_llm_skipped += 1
            v.status = "TRUE"
            v.role   = "AMBIGUOUS"
            continue

        filename = _frame_filename(v)

        verdict = llm_verifier.verify_frame(frame_img, v.type, log_label=filename)
        if verdict["skipped"]:
            n_llm_skipped += 1
        elif verdict["status"] == "FALSE":
            n_llm_rejected += 1
            print(f"[Analyzer:{job_id}]  LLM REJECTED violation "
                  f"(type={v.type} file={filename}): {verdict['reason']}")
        else:
            n_llm_verified += 1
        v.status = verdict["status"]
        v.role   = verdict["role"]

        try:
            s3_key       = upload_frame(frame_img, journey_id,
                                        filename, folder_name=folder_name)
            v.frame_path = s3_key
        except Exception as exc:
            print(f"[Analyzer:{job_id}]  Extracted frame upload failed ({filename}): {exc}")

    # ── LLM verification summary ───────────────────────────────────────────────
    # NOTE: rejected (status="FALSE") candidates are NO LONGER dropped here.
    # Every candidate violation — verified or rejected — is kept and flows
    # through into the completion payload below, tagged with its own
    # status ("TRUE"/"FALSE") and role ("LP"/"ALP"/"BOTH"/"AMBIGUOUS"/None).
    # This lets the backend/UI distinguish confirmed violations from
    # LLM-rejected candidates instead of silently losing the latter.
    _n_total_violations = len(shared_vstore._violations)
    print(
        f"[Analyzer:{job_id}]  LLM verification summary: "
        f"verified(TRUE)={n_llm_verified}  rejected(FALSE)={n_llm_rejected}  "
        f"skipped(no-criteria/disabled)={n_llm_skipped}  "
        f"total={_n_total_violations}"
    )
    print("[LLM_VERIFICATION_SUMMARY] " + json.dumps({
        "job_id":   job_id,
        "journey_id": journey_id,
        "verified_true":  n_llm_verified,
        "rejected_false": n_llm_rejected,
        "skipped_no_llm": n_llm_skipped,
        "total_violations": _n_total_violations,
    }))

    # ── Build VideoResult / ViolationResult objects ───────────────────────────
    violations_by_filename: Dict[str, list] = {}
    for v in shared_vstore._violations:
        violations_by_filename.setdefault(v.source_filename, []).append(v)

    video_results: List[VideoResult] = []


    for vj in ordered:
        meta        = meta_by_id[vj.video_id]
        db_filename = os.path.basename(vj.s3_key)
        raw_viols   = violations_by_filename.get(db_filename, [])

        violation_results = []
        for v in raw_viols:
            # timestamp_seconds: float seconds from journey start (global)
            journey_ts = float(v.timestamp) if hasattr(v, "timestamp") else 0.0

            # original_video_timestamp: float seconds within the source video (local)
            local_ts = _hms_to_seconds(getattr(v, "local_time_str", "0:00:00"))

            violation_results.append(
                ViolationResult(
                    violation_type           = _event_type_to_violation_type(v.type),
                    severity                 = _severity_for_risk(v.risk_score),
                    confidence               = round(v.confidence * 100, 2),
                    risk_score               = float(v.risk_score),
                    timestamp_seconds        = _fmt_duration(journey_ts),
                    original_video_timestamp = _fmt_duration(local_ts),
                    duration_seconds         = float(getattr(v, "duration", 0.0)),
                    trigger_duration_seconds = (
                        getattr(v, "true_duration", None) * 2
                        if getattr(v, "true_duration", None) is not None
                        and _event_type_to_violation_type(v.type) == "SEAT_ABSENCE"
                        else getattr(v, "true_duration", None)
                    ),
                    frame_paths              = [v.frame_path] if v.frame_path else [],
                    status                   = getattr(v, "status", "TRUE"),
                    role                     = getattr(v, "role", None),

                )
            )

        video_results.append(
            VideoResult(
                video_id           = vj.video_id,
                video_name         = db_filename,
                sequence_no        = vj.sequence_no,
                duration_seconds   = meta["duration_seconds"],
                duration_formatted = meta["duration_formatted"],
                fps                = meta["fps"],
                size_mb            = meta["size_mb"],
                original_s3_key    = vj.s3_key,
                violations         = violation_results,
            )
        )

    if failed_video_ids:
        print(
            f"[Analyzer:{job_id}]  Journey analysis complete with "
            f"{len(failed_video_ids)} skipped video(s): {sorted(failed_video_ids)}"
        )

    # Build the failed_videos dict (video_id → error message) that
    # journey_runner.py and consumer.py both expect as the third return value.
    #
    # failed_video_ids is the union of:
    #   • Per-video failures (Scenario 2): exceptions isolated to one video;
    #     the specific exception was already printed above at skip time.
    #   • NOT_PROCESSED videos (Scenario 1): videos AFTER a worker-level OOM
    #     that were never reached; their video_done_cb already fired with
    #     error_type="NOT_PROCESSED" so the Failure API was called immediately.
    #     We still record them here so the caller has a complete picture.
    #
    # Use a specific message for NOT_PROCESSED videos (no meta_by_id entry
    # means the video loop never reached _video_meta for them — they are
    # definitely post-OOM unstarted videos, not per-video failures).
    failed_videos: Dict[int, str] = {}
    for vid in failed_video_ids:
        if vid not in meta_by_id:
            # Never reached — stopped by worker memory failure on a prior video.
            failed_videos[vid] = "Processing stopped due to worker memory failure"
        else:
            # Per-video failure (Scenario 2) or OOM video itself (Scenario 1).
            failed_videos[vid] = "Video processing failed — see worker log for details"

    # ── Fix 6: explicit garbage collection at end of journey ─────────────────
    # By this point every violation's annotated_frame has already been
    # uploaded and cleared (set to None) above, and every per-video pipeline
    # (executor + MediaPipe graphs) has already been explicitly shut down /
    # closed inside GadgetDetectionPipeline.run(). gc.collect() here is a
    # belt-and-suspenders step to promptly reclaim any reference cycles
    # (e.g. exception tracebacks) before the next journey starts.
    n_violations_final = len(shared_vstore._violations)
    _log_resource_snapshot("JOURNEY END (pre-GC)", job_id=job_id,
                            violations=n_violations_final)
    gc.collect()
    _log_resource_snapshot("JOURNEY END (post-GC)", job_id=job_id,
                            violations=n_violations_final)

    return video_results, total_wall_seconds, failed_videos


# ── Private helpers ───────────────────────────────────────────────────────────

def _frame_filename(v) -> str:
    """
    Derive a JPEG filename from a _Violation object (matches _save_frame logic).

    FIX — Wrong/stale frame evidence (filename collision):
    Includes v.frame_index (already unique per violation — it's part of
    record_violation()'s dedup key) so two different violations that
    happen to share the same event type and the same whole-second global
    timestamp can never produce the same filename/S3 key and silently
    overwrite each other's evidence image.
    """
    distraction   = "_".join(sorted(v.events))
    filename_time = v.time_str.replace(":", "-")
    return f"{distraction}_{filename_time}_{v.frame_index}.jpg"